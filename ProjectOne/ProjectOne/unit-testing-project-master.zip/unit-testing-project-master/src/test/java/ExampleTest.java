

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;


// Please delete this file prior to submitting your project.


public class ExampleTest {

    @Test
    public void testJUnitIsConfiguredCorrectly() {
        assertTrue(true);
    }

}
